def almost_equal(a, b):
    return abs(a - b) < 1e-6
